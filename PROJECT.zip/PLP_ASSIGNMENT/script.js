// script.js

// Show and hide the search box when clicking search icon
const searchIcon = document.getElementById('search-icon');
const searchBox = document.getElementById('search-box');

if (searchIcon && searchBox) {
    searchIcon.addEventListener('click', () => {
        if (searchBox.style.display === 'none' || searchBox.style.display === '') {
            searchBox.style.display = 'inline-block';
            searchBox.focus();
        } else {
            searchBox.style.display = 'none';
        }
    });

    // Handle when user presses Enter
    searchBox.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const query = searchBox.value.toLowerCase();

            if (query.includes('home')) {
                window.location.href = 'index.html';
            } else if (query.includes('about')) {
                window.location.href = 'about_me.html';
            } else if (query.includes('services')) {
                window.location.href = 'services.html';
            } else if (query.includes('blog')) {
                window.location.href = 'blogs.html';
            } else if (query.includes('contact')) {
                window.location.href = 'contact.html';
            } else {
                alert('Page not found!');
            }
        }
    });
}
